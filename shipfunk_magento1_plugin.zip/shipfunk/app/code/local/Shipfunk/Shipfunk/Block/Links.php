<?php
class Shipfunk_Shipfunk_Block_Links extends Mage_Checkout_Block_Links
{

}
