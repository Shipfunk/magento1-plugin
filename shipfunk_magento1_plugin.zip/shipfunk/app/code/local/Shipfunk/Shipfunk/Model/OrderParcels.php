<?php 
class Shipfunk_Shipfunk_Model_OrderParcels extends Mage_Core_Model_Abstract
{
	protected function _construct()
	{
		$this->_init('shipfunk/orderParcels');
	}
}

?>