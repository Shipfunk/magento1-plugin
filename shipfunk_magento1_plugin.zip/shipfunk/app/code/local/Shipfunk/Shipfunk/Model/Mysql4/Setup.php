<?php 
class Shipfunk_Shipfunk_Model_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup{
	
}
?>